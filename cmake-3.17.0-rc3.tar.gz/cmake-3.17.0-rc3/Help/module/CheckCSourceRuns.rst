.. cmake-module:: ../../Modules/CheckCSourceRuns.cmake
